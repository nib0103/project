<div align="center">
    <h1>Open Aimbot</h1>
    <p>
        <!-- GitHub Releases -->
        <a href="https://github.com/ttwizz/Open-Aimbot/releases">
            <img src="icons/github-icon.svg" alt="GitHub Releases" />
        </a>
        <!-- Discord Server -->
        <a href="https://twix.cyou/pix">
            <img src="icons/discord-icon.svg" alt="Discord Server" />
        </a>
    </p>
    <!-- Project Information -->
    <!-- Repository Stars -->
    <a href="https://github.com/ttwizz/Open-Aimbot/stargazers">
        <img src="https://img.shields.io/github/stars/ttwizz/Open-Aimbot?label=Stars&logo=GitHub" alt="Repository Stars" />
    </a>
    <!-- Repository Forks -->
    <a href="https://github.com/ttwizz/Open-Aimbot/fork">
        <img src="https://img.shields.io/github/forks/ttwizz/Open-Aimbot?label=Forks&logo=GitHub" alt="Repository Forks" />
    </a>
    <!-- Latest Release -->
    <a href="https://github.com/ttwizz/Open-Aimbot/releases/latest">
        <img src="https://img.shields.io/github/v/release/ttwizz/Open-Aimbot?label=Latest%20Release" alt="Latest Release" />
    </a>
    <!-- Last Modified -->
    <a href="https://github.com/ttwizz/Open-Aimbot/commits">
        <img src="https://img.shields.io/github/last-commit/ttwizz/Open-Aimbot?label=Last%20Modified" alt="Last Modified" />
    </a>

Welcome to the **pix**! We develop various utilities for Roblox, security systems, protection and scripts for specific games, general scenarios. You can find more of our projects on our [Discord Server](https://twix.cyou/pix).
</div>

___

### Open Aimbot
Open Aimbot is a **universal** open source framework. It offers a wide selection of extensive functionality, including:
- ***Over 80 Features***
- ***Detection Bypasses***
- *Alive*, *God*, *Team*, *Friend*, *Follow*, *Verified Badge*, *Wall*, *Water*, *FoV*, *Magnitude*, *Transparency*, *Group*, *Player*, ***Premium*** Checks
- Ability to set *Sensitivity*, *Camera Shaking*, *Mouse & Camera Methods*, *Move Direction Prediction*, *Static, Dynamic & Auto Offset*, *Activation Keys*, *One-Press Mode*, *Target Objects*, *Ignored & Target Players*, *Display Notification Log*, *SpinBot*, *TriggerBot*, *ESP*, *FoV*, *Tracers* and other more subtle options
- Availability of ***Silent Aim***, *Security Warnings*, *Maximum User-Friendliness* and ***Configuration Manager***
- A *Beautiful* and *Unique Interface* that supports *Minimization*, *Maximization* and even ***Resizing***
- ***Support For Absolutely All Exploits And Devices***
- ***Clean*** and ***Understandable Source Code***, providing the simple possibility of *Modification* for your own purposes and *Contribution*

#### Made with love,

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/ttwizz/Open-Aimbot/master/source.lua", true))()
```

<p align="center">
    <img src="https://i.gyazo.com/3c36be2f6dd82c196967d0dcd61145a7.gif" alt="Open Aimbot" />
    Copyright (c) 2024 ttwiz_z
</p>
